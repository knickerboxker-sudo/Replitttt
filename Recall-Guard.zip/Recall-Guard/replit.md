# sortir - Brand-Focused Recall Safety Tracker PWA

## Overview
sortir is a Progressive Web App that helps users track brands they use across all categories (food, vehicles, consumer products) and monitor them for safety recalls from multiple government agencies. Users maintain a personal inventory organized by brand name and can search recalls by brand (e.g., "Ford", "Kroger") or specific item. Integrates with FDA, NHTSA, and CPSC databases.

## Key Features
- **Brand-Centric Tracking**: Organize all items by brand in a unified "My Brands" view
- **Multi-Category Support**: Monitor food, vehicles, and consumer products in one interface
- **Unified Brand Search**: Search across FDA, NHTSA, and CPSC databases simultaneously by brand name
- **Vehicle Tracking**: Add vehicles by make/model/year for NHTSA recall monitoring
- **Product Tracking**: Track consumer products for CPSC safety recalls
- **Unified Alerts**: Dashboard shows all alerts across categories with color-coded urgency
- **Alert Management**: Mark vehicle recalls as fixed, products as discarded
- **iOS-Ready PWA**: Dark mode, bottom navigation, installable on iOS
- **Terms of Service**: Mandatory acceptance flow for legal compliance

## Tech Stack
- **Frontend**: React, TypeScript, TailwindCSS, Shadcn UI
- **Backend**: Express.js, Node.js
- **Database**: PostgreSQL with Drizzle ORM
- **External APIs**: 
  - openFDA (food recalls)
  - NHTSA (vehicle recalls)
  - CPSC (consumer product recalls)

## Project Structure
```
client/
├── src/
│   ├── App.tsx                    # Main app with routing
│   ├── pages/
│   │   ├── HomePage.tsx           # Dashboard with category stats and unified alerts
│   │   ├── MyBrandsPage.tsx       # Brand-centric inventory view (all items grouped by brand)
│   │   ├── VehiclesPage.tsx       # Vehicle tracking with NHTSA recalls
│   │   ├── ProductsPage.tsx       # Consumer product tracking with CPSC recalls
│   │   ├── SearchPage.tsx         # Unified brand search across all recalls
│   │   ├── TermsPage.tsx          # Terms of Service
│   │   └── PrivacyPage.tsx        # Privacy Policy
│   └── components/
│       ├── layout/                # Bottom nav (5 tabs), page container
│       ├── alerts/                # Alert card component (supports UnifiedAlert type)
│       ├── recalls/               # Recall card (supports all recall types)
│       └── legal/                 # Terms acceptance flow

server/
├── routes.ts                      # All API endpoints
├── storage.ts                     # Database operations (CRUD for all entities)
├── db.ts                          # Drizzle database connection
├── fda-client.ts                  # FDA food recalls API
├── nhtsa-client.ts                # NHTSA vehicle recalls + make/model lists
├── cpsc-client.ts                 # CPSC product recalls API
├── vector-store.ts                # Recall matching (stubbed - AI features removed)
└── seed.ts                        # Sample data seeding

shared/
└── schema.ts                      # Database models and types
```

## API Endpoints

### Config & Stats
- `GET /api/config` - Check API configuration
- `GET /api/stats` - Get counts for all categories and recalls

### Food/Pantry (My Brands)
- `POST /api/pantry/save` - Save items to inventory
- `GET /api/pantry` - Get all pantry items
- `PATCH /api/pantry/:id` - Update pantry item
- `POST /api/pantry/toggle_active/:id` - Toggle active/consumed
- `POST /api/pantry/delete/:id` - Delete item

### Vehicles
- `GET /api/vehicles` - List all vehicles with alert counts
- `GET /api/vehicles/:id` - Get vehicle with its alerts
- `POST /api/vehicles/add` - Add new vehicle (fetches NHTSA recalls)
- `GET /api/vehicle-makes` - Get list of vehicle makes
- `GET /api/vehicle-models` - Get list of models for a make
- `POST /api/vehicles/:id/mark-fixed` - Mark recall as fixed
- `DELETE /api/vehicles/:id` - Delete vehicle

### Products
- `GET /api/products` - List all products with alert counts
- `GET /api/products/:id` - Get product with its alerts
- `POST /api/products/add` - Add new product
- `POST /api/products/:id/mark-discarded` - Mark as discarded
- `DELETE /api/products/:id` - Delete product

### Recalls
- `GET /api/recalls` - Get FDA food recalls (supports ?search=)
- `GET /api/vehicle-recalls` - Get NHTSA vehicle recalls
- `GET /api/vehicle-recalls/search` - Search NHTSA by make/model/year
- `GET /api/product-recalls` - Get CPSC product recalls (supports ?search=)
- `POST /api/recalls/refresh` - Refresh all recall databases

### Alerts
- `GET /api/alerts` - Get food alerts with details
- `GET /api/unified-alerts` - Get all alerts across categories
- `POST /api/alerts/dismiss/:id` - Dismiss alert (with category)

## Database Schema

### Items
- **pantry_items**: id, brand, product_name, size, purchase_date, date_added, is_active
- **vehicles**: id, make, model, year, vin, nickname, date_added, is_active
- **products**: id, brand, product_name, model_number, category, purchase_date, purchase_location, date_added, is_active

### Recalls
- **recalls**: recall_id, product_description, reason, classification, company, recall_date, raw_json, date_fetched
- **vehicle_recalls**: id, campaign_number, make, model, year, component, summary, consequence, remedy, manufacturer, recall_date, severity, raw_json, date_fetched
- **product_recalls**: id, recall_number, product_name, description, hazard, remedy, manufacturer, recall_date, image_url, cpsc_url, units_affected, raw_json, date_fetched

### Alerts
- **alerts**: id, pantry_item_id, recall_id, score, urgency, message, created_at, is_dismissed
- **vehicle_alerts**: id, vehicle_id, vehicle_recall_id, score, urgency, message, is_fixed, created_at, is_dismissed
- **product_alerts**: id, product_id, product_recall_id, score, urgency, message, is_discarded, created_at, is_dismissed

### System
- **system_settings**: key, value, updated_at

## Color Coding
- **Food (Green)**: Pantry/brand items and FDA recalls
- **Vehicles (Blue)**: Vehicle tracking and NHTSA recalls
- **Products (Purple)**: Consumer products and CPSC recalls
- **My Brands (Pink)**: Heart icon for brand-centric inventory

## Navigation
Bottom navigation with 5 tabs:
1. Home - Dashboard with stats and alerts
2. My Brands - All items grouped by brand name
3. Vehicles - Vehicle tracking
4. Products - Consumer product tracking
5. Search - Unified brand search across all recall databases

## Environment Variables
- `DATABASE_URL` - PostgreSQL connection string (auto-configured)

## Running the App
The app runs on port 5000 with `npm run dev`. Use "Refresh" button on homepage to fetch latest recalls from all agencies.

## Installing as iOS App
This is a Progressive Web App (PWA) optimized for iOS:

1. Open the app in Safari on iPhone
2. Tap the Share button (square with arrow)
3. Scroll down and tap "Add to Home Screen"
4. Tap "Add" to install

## Notes
- No authentication required - single user app
- Dark mode only (iOS-style design)
- AI scanning features have been removed - manual item entry only
- Vehicle recalls are fetched automatically when a vehicle is added
- Unified search searches all three government databases simultaneously
