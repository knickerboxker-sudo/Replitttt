import { Package, Check, Trash2, MoreVertical, Edit2, Search } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";
import type { PantryItem } from "@shared/schema";
import { format } from "date-fns";
import { EditPantryItemDialog } from "./EditPantryItemDialog";
import { useLocation } from "wouter";

interface PantryItemCardProps {
  item: PantryItem;
  onToggleActive: (id: number) => void;
  onDelete: (id: number) => void;
}

export function PantryItemCard({ item, onToggleActive, onDelete }: PantryItemCardProps) {
  const [, setLocation] = useLocation();
  const dateAdded = item.dateAdded ? format(new Date(item.dateAdded), "MMM d, yyyy") : "Unknown";

  const handleSearchRecalls = () => {
    const query = `${item.brand || ""} ${item.productName}`.trim();
    setLocation(`/recalls?search=${encodeURIComponent(query)}`);
  };

  return (
    <Card 
      className={cn(
        "relative overflow-visible border border-border transition-all duration-200",
        !item.isActive && "opacity-60"
      )}
      data-testid={`pantry-item-${item.id}`}
    >
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          <div className={cn(
            "w-10 h-10 rounded-lg flex items-center justify-center",
            item.isActive ? "bg-primary/10" : "bg-muted"
          )}>
            <Package className={cn(
              "w-5 h-5",
              item.isActive ? "text-primary" : "text-muted-foreground"
            )} />
          </div>
          
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <h4 className="font-medium text-sm line-clamp-1">
                {item.productName}
              </h4>
              {!item.isActive && (
                <Badge variant="secondary" className="text-xs">
                  Consumed
                </Badge>
              )}
            </div>
            
            {item.brand && (
              <p className="text-xs text-muted-foreground mb-1">
                {item.brand}
              </p>
            )}
            
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              {item.size && <span>{item.size}</span>}
              {item.size && <span>•</span>}
              <span>Added {dateAdded}</span>
            </div>
          </div>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                data-testid={`pantry-item-menu-${item.id}`}
              >
                <MoreVertical className="w-4 h-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={handleSearchRecalls}>
                <Search className="w-4 h-4 mr-2" />
                Search Recalls
              </DropdownMenuItem>
              <EditPantryItemDialog 
                item={item} 
                trigger={
                  <DropdownMenuItem onSelect={(e) => e.preventDefault()}>
                    <Edit2 className="w-4 h-4 mr-2" />
                    Edit Details
                  </DropdownMenuItem>
                }
              />
              <DropdownMenuItem 
                onClick={() => onToggleActive(item.id)}
                data-testid={`toggle-active-${item.id}`}
              >
                <Check className="w-4 h-4 mr-2" />
                {item.isActive ? "Mark as consumed" : "Mark as active"}
              </DropdownMenuItem>
              <DropdownMenuItem 
                onClick={() => onDelete(item.id)}
                className="text-destructive focus:text-destructive"
                data-testid={`delete-item-${item.id}`}
              >
                <Trash2 className="w-4 h-4 mr-2" />
                Delete
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </CardContent>
    </Card>
  );
}

export function PantryItemSkeleton() {
  return (
    <Card className="border border-border">
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-lg bg-muted animate-pulse" />
          <div className="flex-1 space-y-2">
            <div className="w-3/4 h-4 rounded bg-muted animate-pulse" />
            <div className="w-1/2 h-3 rounded bg-muted animate-pulse" />
            <div className="w-1/3 h-3 rounded bg-muted animate-pulse" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
