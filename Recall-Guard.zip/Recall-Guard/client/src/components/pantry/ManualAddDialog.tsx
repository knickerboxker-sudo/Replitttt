import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Plus } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { apiRequest } from "@/lib/queryClient";
import { insertPantryItemSchema, type InsertPantryItem } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export function ManualAddDialog() {
  const [open, setOpen] = useState(false);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const form = useForm<InsertPantryItem>({
    resolver: zodResolver(insertPantryItemSchema),
    defaultValues: {
      brand: "",
      productName: "",
      size: "",
      purchaseDate: new Date().toISOString().split('T')[0],
      isActive: true,
    },
  });

  const mutation = useMutation({
    mutationFn: (values: InsertPantryItem) => {
      // The backend expects { items: [...] } for /api/pantry/save
      // but let's see if there's a single save endpoint.
      // Based on previous logs, /api/pantry/save takes an array of items.
      const formattedItem = {
        brand: values.brand,
        product_name: values.productName,
        size_or_quantity: values.size,
        purchase_date: values.purchaseDate,
      };
      return apiRequest("POST", "/api/pantry/save", { items: [formattedItem] });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/pantry"] });
      queryClient.invalidateQueries({ queryKey: ["/api/alerts"] });
      setOpen(false);
      form.reset();
      toast({
        title: "Item added",
        description: "The item has been added to your pantry.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="w-full gap-2" data-testid="button-manual-add">
          <Plus className="w-4 h-4" />
          Add Manually
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Add Pantry Item</DialogTitle>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit((data) => mutation.mutate(data))} className="space-y-4">
            <FormField
              control={form.control}
              name="brand"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Brand (Optional)</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="e.g. Kellogg's" 
                      {...field} 
                      value={field.value ?? ""} 
                      data-testid="input-brand" 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="productName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Product Name</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="e.g. Corn Flakes" 
                      {...field} 
                      value={field.value ?? ""} 
                      data-testid="input-product-name" 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="size"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Size/Quantity (Optional)</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="e.g. 18 oz" 
                      {...field} 
                      value={field.value ?? ""} 
                      data-testid="input-size" 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="purchaseDate"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Purchase Date (Optional)</FormLabel>
                  <FormControl>
                    <Input 
                      type="date" 
                      {...field} 
                      value={field.value ?? ""} 
                      data-testid="input-purchase-date" 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <DialogFooter>
              <Button type="submit" disabled={mutation.isPending} data-testid="button-save-item">
                {mutation.isPending ? "Adding..." : "Add to Pantry"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
