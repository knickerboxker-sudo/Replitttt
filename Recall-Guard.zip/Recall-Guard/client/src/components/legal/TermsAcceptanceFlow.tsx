import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Shield, Check } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Link } from "wouter";

export function TermsAcceptanceFlow() {
  const [isOpen, setIsOpen] = useState(false);
  const [acceptedTerms, setAcceptedTerms] = useState(false);
  const [acceptedPrivacy, setAcceptedPrivacy] = useState(false);
  const [understandLimitations, setUnderstandLimitations] = useState(false);

  const { data: termsStatus, isLoading } = useQuery({
    queryKey: ["/api/terms-status"],
  });

  useEffect(() => {
    if (!isLoading && termsStatus && !termsStatus.accepted) {
      setIsOpen(true);
    }
  }, [termsStatus, isLoading]);

  const acceptMutation = useMutation({
    mutationFn: () => apiRequest("POST", "/api/accept-terms", {
      accepted_terms: true,
      accepted_privacy: true,
      timestamp: new Date().toISOString()
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/terms-status"] });
      setIsOpen(false);
    },
  });

  const canContinue = acceptedTerms && acceptedPrivacy && understandLimitations;

  return (
    <Dialog open={isOpen} onOpenChange={() => {}}>
      <DialogContent className="max-w-md pointer-events-auto" onInteractOutside={(e) => e.preventDefault()}>
        <DialogHeader>
          <div className="flex items-center gap-2 mb-2">
            <Shield className="w-6 h-6 text-primary" />
            <DialogTitle className="text-xl">Welcome to Sortir</DialogTitle>
          </div>
          <p className="text-sm text-muted-foreground">
            Before you get started, please review and accept our terms.
          </p>
        </DialogHeader>

        <div className="space-y-6 my-4">
          <div className="bg-muted/50 p-4 rounded-lg space-y-2">
            <h3 className="text-sm font-semibold flex items-center gap-2">
              <Check className="w-4 h-4 text-green-500" />
              Quick Summary:
            </h3>
            <ul className="text-xs space-y-1 text-muted-foreground">
              <li>• Monitors public recall databases (FDA, NHTSA, CPSC)</li>
              <li>• Uses AI to match your items to recalls</li>
              <li>• Information provided "as-is" - verification recommended</li>
              <li>• We don't sell your data and you can delete it anytime</li>
            </ul>
          </div>

          <div className="space-y-4">
            <div className="flex items-start space-x-3">
              <Checkbox 
                id="terms" 
                checked={acceptedTerms} 
                onCheckedChange={(checked) => setAcceptedTerms(!!checked)}
                data-testid="checkbox-terms"
              />
              <div className="grid gap-1.5 leading-none">
                <Label htmlFor="terms" className="text-sm">
                  I agree to the <Link href="/terms" target="_blank" className="text-primary hover:underline">Terms of Service</Link>
                </Label>
              </div>
            </div>

            <div className="flex items-start space-x-3">
              <Checkbox 
                id="privacy" 
                checked={acceptedPrivacy} 
                onCheckedChange={(checked) => setAcceptedPrivacy(!!checked)}
                data-testid="checkbox-privacy"
              />
              <div className="grid gap-1.5 leading-none">
                <Label htmlFor="privacy" className="text-sm">
                  I agree to the <Link href="/privacy" target="_blank" className="text-primary hover:underline">Privacy Policy</Link>
                </Label>
              </div>
            </div>

            <div className="flex items-start space-x-3">
              <Checkbox 
                id="limitations" 
                checked={understandLimitations} 
                onCheckedChange={(checked) => setUnderstandLimitations(!!checked)}
                data-testid="checkbox-limitations"
              />
              <div className="grid gap-1.5 leading-none">
                <Label htmlFor="limitations" className="text-sm">
                  I understand Sortir is an informational tool and cannot guarantee all recalls will be detected
                </Label>
              </div>
            </div>
          </div>
        </div>

        <DialogFooter className="flex-col sm:flex-col gap-2">
          <Button 
            className="w-full" 
            disabled={!canContinue || acceptMutation.isPending}
            onClick={() => acceptMutation.mutate()}
            data-testid="button-continue-to-app"
          >
            {acceptMutation.isPending ? "Setting up..." : "Continue to Sortir"}
          </Button>
          <p className="text-[10px] text-center text-muted-foreground">
            By clicking Continue, you acknowledge you've read our terms and understand this is a best-effort service.
          </p>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
