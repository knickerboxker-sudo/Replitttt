import { AlertTriangle, ChevronRight, X } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import type { UnifiedAlert } from "@shared/schema";

interface AlertCardProps {
  alert: UnifiedAlert;
  onDismiss: (id: number) => void;
  onClick?: () => void;
}

const urgencyStyles = {
  HIGH: {
    bg: "bg-red-500/10",
    border: "border-red-500/30",
    badge: "bg-red-500/20 text-red-400 border-red-500/30",
    icon: "text-red-400",
  },
  MEDIUM: {
    bg: "bg-orange-500/10",
    border: "border-orange-500/30",
    badge: "bg-orange-500/20 text-orange-400 border-orange-500/30",
    icon: "text-orange-400",
  },
  LOW: {
    bg: "bg-yellow-500/10",
    border: "border-yellow-500/30",
    badge: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
    icon: "text-yellow-400",
  },
};

export function AlertCard({ alert, onDismiss, onClick }: AlertCardProps) {
  const styles = urgencyStyles[alert.urgency as keyof typeof urgencyStyles] || urgencyStyles.LOW;

  return (
    <Card 
      className={cn(
        "relative overflow-visible border transition-all duration-200 hover-elevate cursor-pointer",
        styles.bg,
        styles.border
      )}
      onClick={onClick}
      data-testid={`alert-card-${alert.id}`}
    >
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          <div className={cn("mt-0.5", styles.icon)}>
            <AlertTriangle className="w-5 h-5" />
          </div>
          
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <Badge 
                variant="outline" 
                className={cn("text-xs font-medium", styles.badge)}
              >
                {alert.urgency}
              </Badge>
              <span className="text-xs text-muted-foreground capitalize">
                {alert.category}
              </span>
            </div>
            
            <h4 className="font-medium text-sm mb-1 line-clamp-1">
              {alert.itemName}
            </h4>
            
            <p className="text-xs text-muted-foreground line-clamp-2">
              {alert.message || alert.recallTitle}
            </p>
          </div>
          
          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 text-muted-foreground"
              onClick={(e) => {
                e.stopPropagation();
                onDismiss(alert.id);
              }}
              data-testid={`dismiss-alert-${alert.id}`}
            >
              <X className="w-4 h-4" />
            </Button>
            <ChevronRight className="w-4 h-4 text-muted-foreground" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export function AlertCardSkeleton() {
  return (
    <Card className="border bg-muted/10">
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          <div className="w-5 h-5 rounded bg-muted animate-pulse" />
          <div className="flex-1 space-y-2">
            <div className="flex items-center gap-2">
              <div className="w-16 h-5 rounded bg-muted animate-pulse" />
            </div>
            <div className="w-3/4 h-4 rounded bg-muted animate-pulse" />
            <div className="w-full h-3 rounded bg-muted animate-pulse" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
