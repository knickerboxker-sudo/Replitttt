import { PageContainer } from "@/components/layout/PageContainer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";

export default function TermsPage() {
  const currentYear = new Date().getFullYear();

  return (
    <PageContainer>
      <div className="py-8">
        <Card className="max-w-3xl mx-auto">
          <CardHeader>
            <CardTitle className="text-2xl">Terms of Service for Sortir</CardTitle>
            <p className="text-sm text-muted-foreground">Last Updated: January 31, {currentYear}</p>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[60vh] pr-4">
              <div className="space-y-6 text-sm">
                <section>
                  <h3 className="font-bold text-base mb-2">1. Acceptance of Terms</h3>
                  <p>By accessing or using Sortir ("the Service"), you agree to be bound by these Terms of Service. If you do not agree to these terms, do not use the Service.</p>
                </section>

                <section>
                  <h3 className="font-bold text-base mb-2">2. Description of Service</h3>
                  <p>Sortir is an informational platform that aggregates publicly available recall data from government databases including:</p>
                  <ul className="list-disc pl-5 mt-2 space-y-1">
                    <li>FDA Food Enforcement Reports</li>
                    <li>NHTSA Vehicle Safety Recalls</li>
                    <li>CPSC Consumer Product Safety Recalls</li>
                  </ul>
                  <p className="mt-2">The Service uses artificial intelligence to help users monitor potential recalls affecting their registered items.</p>
                </section>

                <section>
                  <h3 className="font-bold text-base mb-2 text-destructive">3. No Warranty - Information Provided "As-Is"</h3>
                  <p className="font-semibold uppercase">THE SERVICE IS PROVIDED "AS-IS" WITHOUT ANY WARRANTIES OF ANY KIND, EXPRESS OR IMPLIED.</p>
                  <ul className="list-disc pl-5 mt-2 space-y-1">
                    <li>Sortir aggregates data from public government sources but CANNOT guarantee completeness, accuracy, or timeliness of recall information</li>
                    <li>We are NOT responsible for missing recalls, delayed notifications, or inaccurate data</li>
                    <li>Recall data depends on third-party government APIs which may experience downtime, delays, or errors</li>
                    <li>Our AI matching system uses semantic similarity and may produce false positives or miss valid matches</li>
                    <li>We are NOT a substitute for official manufacturer recall notifications</li>
                  </ul>
                </section>

                <section>
                  <h3 className="font-bold text-base mb-2">4. User Responsibilities</h3>
                  <p>You are solely responsible for:</p>
                  <ul className="list-disc pl-5 mt-2 space-y-1">
                    <li>Verifying recall information with manufacturers and official sources</li>
                    <li>Maintaining your vehicles, products, and food items safely</li>
                    <li>Checking official recall databases (NHTSA.gov, FDA.gov, CPSC.gov) independently</li>
                    <li>Responding appropriately to recall notices</li>
                    <li>Keeping your registered items current and accurate</li>
                  </ul>
                </section>

                <section>
                  <h3 className="font-bold text-base mb-2">5. Limitation of Liability</h3>
                  <p className="font-semibold uppercase">TO THE MAXIMUM EXTENT PERMITTED BY LAW:</p>
                  <ul className="list-disc pl-5 mt-2 space-y-1">
                    <li>Sortir, its creators, operators, and affiliates SHALL NOT BE LIABLE for any damages arising from use or inability to use the Service</li>
                    <li>This includes but is not limited to: personal injury, property damage, economic loss, or any consequential damages</li>
                    <li>We are NOT liable for missed recalls, inaccurate matches, or delayed notifications</li>
                    <li>You use the Service at your own risk</li>
                    <li>Your sole remedy for dissatisfaction is to stop using the Service</li>
                  </ul>
                </section>

                <section>
                  <h3 className="font-bold text-base mb-2">6. No Professional Relationship</h3>
                  <p>Sortir does not provide legal, medical, or professional advice. We are not mechanics, food safety experts, or product safety inspectors. Nothing in the Service creates a duty of care or professional relationship.</p>
                </section>

                <section>
                  <h3 className="font-bold text-base mb-2">7. User Data & Privacy</h3>
                  <p>We collect and store information about items you register (vehicles, food purchases, products). We use Cohere AI to process images and text data. See our Privacy Policy for details on data handling. You retain ownership of your data and may delete it at any time.</p>
                </section>

                <section>
                  <h3 className="font-bold text-base mb-2">8. API Data Sources</h3>
                  <p>We use the following public APIs: openFDA API, NHTSA API, and CPSC API. These agencies retain ownership of recall data. We are simply an aggregator.</p>
                </section>

                <section>
                  <h3 className="font-bold text-base mb-2">9. Governing Law</h3>
                  <p>These Terms are governed by the laws of the United States. Any disputes shall be resolved in applicable courts.</p>
                </section>
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      </div>
    </PageContainer>
  );
}
