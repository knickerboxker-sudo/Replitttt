import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Search, RefreshCw, Car, Utensils, Package, Info, Building2, ChevronDown, ChevronUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { PageContainer } from "@/components/layout/PageContainer";
import { RecallCard, RecallCardSkeleton } from "@/components/recalls/RecallCard";
import { EmptyState } from "@/components/ui/empty-state";
import { LoadingSpinner } from "@/components/ui/loading-spinner";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import type { Recall, VehicleRecall, ProductRecall } from "@shared/schema";

interface UnifiedSearchResults {
  food: Recall[];
  vehicle: VehicleRecall[];
  product: ProductRecall[];
}

export default function SearchPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [hasSearched, setHasSearched] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  const [results, setResults] = useState<UnifiedSearchResults>({ food: [], vehicle: [], product: [] });
  const [expandedSections, setExpandedSections] = useState({
    food: false,
    vehicle: false,
    product: false
  });
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: availableMakes = [] } = useQuery<string[]>({
    queryKey: ["/api/vehicle-makes"],
    queryFn: async () => {
      const res = await fetch("/api/vehicle-makes");
      if (!res.ok) return [];
      return res.json();
    },
  });

  const totalResults = results.food.length + results.vehicle.length + results.product.length;

  const toggleSection = (section: 'food' | 'vehicle' | 'product') => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }));
  };

  const handleSearch = async (e?: React.FormEvent) => {
    e?.preventDefault();

    if (!searchQuery.trim()) {
      toast({
        title: "Brand name required",
        description: "Please enter a brand or company name to search for recalls.",
        variant: "destructive",
      });
      return;
    }

    setIsSearching(true);
    setHasSearched(true);
    // Reset expanded sections on new search
    setExpandedSections({ food: false, vehicle: false, product: false });

    try {
      const [foodRes, productRes] = await Promise.all([
        fetch(`/api/recalls?search=${encodeURIComponent(searchQuery)}`),
        fetch(`/api/product-recalls?search=${encodeURIComponent(searchQuery)}`),
      ]);

      const foodData = foodRes.ok ? await foodRes.json() : [];
      const productData = productRes.ok ? await productRes.json() : [];

      let vehicleData: VehicleRecall[] = [];
      const searchQueryLower = searchQuery.toLowerCase().trim();
      const isKnownMake = availableMakes.some(
        (make) => make.toLowerCase() === searchQueryLower || make.toLowerCase().includes(searchQueryLower)
      );

      if (isKnownMake) {
        const matchingMake = availableMakes.find(
          (make) => make.toLowerCase() === searchQueryLower
        ) || availableMakes.find(
          (make) => make.toLowerCase().includes(searchQueryLower)
        );

        if (matchingMake) {
          const vehicleRes = await fetch(
            `/api/vehicle-recalls/search?make=${encodeURIComponent(matchingMake)}&yearStart=${new Date().getFullYear() - 10}&yearEnd=${new Date().getFullYear()}`
          );
          if (vehicleRes.ok) {
            vehicleData = await vehicleRes.json();
          }
        }
      }

      setResults({
        food: foodData,
        vehicle: vehicleData,
        product: productData,
      });

      if (foodData.length === 0 && vehicleData.length === 0 && productData.length === 0) {
        toast({
          title: "No recalls found",
          description: `No recalls found for "${searchQuery}". Try a different brand name.`,
        });
      }
    } catch (error) {
      toast({
        title: "Search failed",
        description: "Unable to search recall databases. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSearching(false);
    }
  };

  const refreshMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/recalls/refresh");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/recalls"] });
      queryClient.invalidateQueries({ queryKey: ["/api/vehicle-recalls"] });
      queryClient.invalidateQueries({ queryKey: ["/api/product-recalls"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      toast({
        title: "Recalls refreshed",
        description: "Fetched latest recalls from FDA, NHTSA, and CPSC",
      });
    },
  });

  const clearSearch = () => {
    setSearchQuery("");
    setHasSearched(false);
    setResults({ food: [], vehicle: [], product: [] });
    setExpandedSections({ food: false, vehicle: false, product: false });
  };

  const PREVIEW_LIMIT = 5;

  return (
    <PageContainer>
      <div className="space-y-6 py-4">
        <div className="flex items-center justify-between gap-4">
          <div>
            <h1 className="text-xl font-bold tracking-tight">Search Recalls</h1>
            <p className="text-sm text-muted-foreground">
              Search by brand name across all categories
            </p>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => refreshMutation.mutate()}
            disabled={refreshMutation.isPending}
            data-testid="button-refresh-recalls"
          >
            {refreshMutation.isPending ? (
              <LoadingSpinner size="sm" className="mr-2" />
            ) : (
              <RefreshCw className="w-4 h-4 mr-2" />
            )}
            Refresh
          </Button>
        </div>

        <form onSubmit={handleSearch} className="space-y-4">
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Building2 className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Enter brand name (e.g., Ford, Kroger, Fisher-Price)"
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  if (hasSearched) setHasSearched(false);
                }}
                className="pl-9"
                data-testid="input-brand-search"
              />
            </div>
            <Button 
              type="submit" 
              disabled={isSearching}
              data-testid="button-submit-search"
            >
              {isSearching ? (
                <LoadingSpinner size="sm" />
              ) : (
                <>
                  <Search className="w-4 h-4 mr-2" />
                  Search
                </>
              )}
            </Button>
          </div>

          <Card className="bg-muted/30 border-dashed">
            <CardContent className="p-3 flex items-start gap-3">
              <Info className="w-4 h-4 text-muted-foreground mt-0.5 shrink-0" />
              <p className="text-xs text-muted-foreground">
                Searches FDA food recalls, NHTSA vehicle recalls, and CPSC product recalls simultaneously.
                Enter a brand or company name to find all related safety notices.
              </p>
            </CardContent>
          </Card>
        </form>

        {isSearching ? (
          <div className="space-y-3">
            <RecallCardSkeleton />
            <RecallCardSkeleton />
            <RecallCardSkeleton />
          </div>
        ) : !hasSearched ? (
          <EmptyState
            icon={Search}
            title="Search for Brand Recalls"
            description="Enter a brand or company name to search across FDA, NHTSA, and CPSC databases for safety recalls."
          />
        ) : totalResults === 0 ? (
          <EmptyState
            icon={Search}
            title="No results found"
            description={`No recalls found for "${searchQuery}". Try a different brand or company name.`}
            action={
              <Button variant="outline" onClick={clearSearch}>
                Clear Search
              </Button>
            }
          />
        ) : (
          <div className="space-y-6">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-sm text-muted-foreground">Found {totalResults} recalls:</span>
              {results.food.length > 0 && (
                <Badge variant="outline" className="bg-green-500/10 text-green-500 border-green-500/30">
                  <Utensils className="w-3 h-3 mr-1" />
                  {results.food.length} Food
                </Badge>
              )}
              {results.vehicle.length > 0 && (
                <Badge variant="outline" className="bg-blue-500/10 text-blue-500 border-blue-500/30">
                  <Car className="w-3 h-3 mr-1" />
                  {results.vehicle.length} Vehicle
                </Badge>
              )}
              {results.product.length > 0 && (
                <Badge variant="outline" className="bg-purple-500/10 text-purple-500 border-purple-500/30">
                  <Package className="w-3 h-3 mr-1" />
                  {results.product.length} Product
                </Badge>
              )}
            </div>

            {results.food.length > 0 && (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-1 h-5 rounded-full bg-green-500" />
                    <h2 className="font-semibold text-sm text-green-500">FDA Food Recalls</h2>
                  </div>
                  {results.food.length > PREVIEW_LIMIT && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => toggleSection('food')}
                      className="text-xs"
                    >
                      {expandedSections.food ? (
                        <>
                          <ChevronUp className="w-4 h-4 mr-1" />
                          Show Less
                        </>
                      ) : (
                        <>
                          <ChevronDown className="w-4 h-4 mr-1" />
                          Show All ({results.food.length})
                        </>
                      )}
                    </Button>
                  )}
                </div>
                {(expandedSections.food ? results.food : results.food.slice(0, PREVIEW_LIMIT)).map((recall, i) => (
                  <RecallCard key={recall.recallId || i} recall={recall} />
                ))}
              </div>
            )}

            {results.vehicle.length > 0 && (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-1 h-5 rounded-full bg-blue-500" />
                    <h2 className="font-semibold text-sm text-blue-500">NHTSA Vehicle Recalls</h2>
                  </div>
                  {results.vehicle.length > PREVIEW_LIMIT && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => toggleSection('vehicle')}
                      className="text-xs"
                    >
                      {expandedSections.vehicle ? (
                        <>
                          <ChevronUp className="w-4 h-4 mr-1" />
                          Show Less
                        </>
                      ) : (
                        <>
                          <ChevronDown className="w-4 h-4 mr-1" />
                          Show All ({results.vehicle.length})
                        </>
                      )}
                    </Button>
                  )}
                </div>
                {(expandedSections.vehicle ? results.vehicle : results.vehicle.slice(0, PREVIEW_LIMIT)).map((recall, i) => (
                  <RecallCard key={recall.campaignNumber || i} recall={recall} />
                ))}
              </div>
            )}

            {results.product.length > 0 && (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-1 h-5 rounded-full bg-purple-500" />
                    <h2 className="font-semibold text-sm text-purple-500">CPSC Product Recalls</h2>
                  </div>
                  {results.product.length > PREVIEW_LIMIT && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => toggleSection('product')}
                      className="text-xs"
                    >
                      {expandedSections.product ? (
                        <>
                          <ChevronUp className="w-4 h-4 mr-1" />
                          Show Less
                        </>
                      ) : (
                        <>
                          <ChevronDown className="w-4 h-4 mr-1" />
                          Show All ({results.product.length})
                        </>
                      )}
                    </Button>
                  )}
                </div>
                {(expandedSections.product ? results.product : results.product.slice(0, PREVIEW_LIMIT)).map((recall, i) => (
                  <RecallCard key={recall.recallNumber || i} recall={recall} />
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </PageContainer>
  );
}
