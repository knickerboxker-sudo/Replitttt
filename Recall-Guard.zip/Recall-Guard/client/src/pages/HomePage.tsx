import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Car, Package, AlertTriangle, RefreshCw, Shield, Heart, Search, Utensils } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { PageContainer } from "@/components/layout/PageContainer";
import { AlertCard, AlertCardSkeleton } from "@/components/alerts/AlertCard";
import { EmptyState } from "@/components/ui/empty-state";
import { apiRequest } from "@/lib/queryClient";
import type { UnifiedAlert } from "@shared/schema";
import { Link } from "wouter";

interface Stats {
  recallCount: number;
  vehicleRecallCount: number;
  productRecallCount: number;
  totalRecalls: number;
  lastFetch: string | null;
  pantryCount: number;
  vehicleCount: number;
  productCount: number;
}

export default function HomePage() {
  const queryClient = useQueryClient();

  const { data: alerts = [], isLoading: alertsLoading } = useQuery<UnifiedAlert[]>({
    queryKey: ["/api/unified-alerts"],
  });

  const { data: stats } = useQuery<Stats>({
    queryKey: ["/api/stats"],
  });

  const refreshMutation = useMutation({
    mutationFn: () => apiRequest("POST", "/api/recalls/refresh"),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/unified-alerts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/recalls"] });
    },
  });

  const dismissMutation = useMutation({
    mutationFn: ({ id, category }: { id: number; category: string }) => 
      apiRequest("POST", `/api/alerts/dismiss/${id}`, { category }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/unified-alerts"] });
    },
  });

  const activeAlerts = alerts.filter(a => !a.isDismissed && !a.isResolved);
  const foodAlerts = activeAlerts.filter(a => a.category === "food");
  const vehicleAlerts = activeAlerts.filter(a => a.category === "vehicle");
  const productAlerts = activeAlerts.filter(a => a.category === "product");

  const totalItems = (stats?.pantryCount || 0) + (stats?.vehicleCount || 0) + (stats?.productCount || 0);

  return (
    <PageContainer>
      <div className="space-y-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold flex items-center gap-2">
              <Shield className="w-6 h-6 text-primary" />
              Dashboard
            </h1>
            <p className="text-sm text-muted-foreground">
              {totalItems} items tracked across all categories
            </p>
          </div>
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => refreshMutation.mutate()}
            disabled={refreshMutation.isPending}
            data-testid="button-refresh-recalls"
          >
            <RefreshCw className={`w-4 h-4 mr-2 ${refreshMutation.isPending ? "animate-spin" : ""}`} />
            Refresh
          </Button>
        </div>

        <div className="grid grid-cols-3 gap-3">
          <Link href="/my-brands">
            <Card className="hover-elevate cursor-pointer border-pink-500/20">
              <CardContent className="p-3">
                <div className="flex flex-col items-center gap-2">
                  <div className="w-10 h-10 rounded-lg bg-pink-500/10 flex items-center justify-center">
                    <Heart className="w-5 h-5 text-pink-500" />
                  </div>
                  <div className="text-center">
                    <p className="text-lg font-semibold">{(stats?.pantryCount || 0) + (stats?.vehicleCount || 0) + (stats?.productCount || 0)}</p>
                    <p className="text-[10px] text-muted-foreground">My Brands</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>
          
          <Link href="/vehicles">
            <Card className="hover-elevate cursor-pointer border-blue-500/20">
              <CardContent className="p-3">
                <div className="flex flex-col items-center gap-2">
                  <div className="w-10 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center">
                    <Car className="w-5 h-5 text-blue-500" />
                  </div>
                  <div className="text-center">
                    <p className="text-lg font-semibold">{stats?.vehicleCount || 0}</p>
                    <p className="text-[10px] text-muted-foreground">Vehicles</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>
          
          <Link href="/products">
            <Card className="hover-elevate cursor-pointer border-purple-500/20">
              <CardContent className="p-3">
                <div className="flex flex-col items-center gap-2">
                  <div className="w-10 h-10 rounded-lg bg-purple-500/10 flex items-center justify-center">
                    <Package className="w-5 h-5 text-purple-500" />
                  </div>
                  <div className="text-center">
                    <p className="text-lg font-semibold">{stats?.productCount || 0}</p>
                    <p className="text-[10px] text-muted-foreground">Products</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>
        </div>

        <Link href="/recalls">
          <Card className="hover-elevate cursor-pointer bg-primary/5 border-primary/20">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                    <Search className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-semibold">Search Recalls</p>
                    <p className="text-xs text-muted-foreground">
                      Search FDA, NHTSA & CPSC databases
                    </p>
                  </div>
                </div>
                <Badge variant="outline" className="text-xs">
                  {(stats?.recallCount || 0) + (stats?.vehicleRecallCount || 0) + (stats?.productRecallCount || 0)} total
                </Badge>
              </div>
            </CardContent>
          </Card>
        </Link>

        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-orange-500" />
              Your Alerts
            </h2>
            {activeAlerts.length > 0 && (
              <Badge variant="destructive">
                {activeAlerts.length} active
              </Badge>
            )}
          </div>

          {alertsLoading ? (
            <>
              <AlertCardSkeleton />
              <AlertCardSkeleton />
            </>
          ) : activeAlerts.length === 0 ? (
            <EmptyState
              icon={Shield}
              title="No active alerts"
              description="Add brands you use to get notified about recalls that may affect you."
            />
          ) : (
            <div className="space-y-3">
              {vehicleAlerts.length > 0 && (
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm text-blue-500">
                    <Car className="w-4 h-4" />
                    <span className="font-medium">Vehicle Alerts ({vehicleAlerts.length})</span>
                  </div>
                  {vehicleAlerts.slice(0, 3).map((alert) => (
                    <AlertCard
                      key={`vehicle-${alert.id}`}
                      alert={alert}
                      onDismiss={(id) => dismissMutation.mutate({ id, category: "vehicle" })}
                    />
                  ))}
                </div>
              )}

              {foodAlerts.length > 0 && (
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm text-green-500">
                    <Utensils className="w-4 h-4" />
                    <span className="font-medium">Food Alerts ({foodAlerts.length})</span>
                  </div>
                  {foodAlerts.slice(0, 3).map((alert) => (
                    <AlertCard
                      key={`food-${alert.id}`}
                      alert={alert}
                      onDismiss={(id) => dismissMutation.mutate({ id, category: "food" })}
                    />
                  ))}
                </div>
              )}

              {productAlerts.length > 0 && (
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm text-purple-500">
                    <Package className="w-4 h-4" />
                    <span className="font-medium">Product Alerts ({productAlerts.length})</span>
                  </div>
                  {productAlerts.slice(0, 3).map((alert) => (
                    <AlertCard
                      key={`product-${alert.id}`}
                      alert={alert}
                      onDismiss={(id) => dismissMutation.mutate({ id, category: "product" })}
                    />
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </PageContainer>
  );
}
