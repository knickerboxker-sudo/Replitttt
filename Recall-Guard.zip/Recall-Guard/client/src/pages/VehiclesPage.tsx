import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Car, Plus, AlertTriangle, CheckCircle, Trash2, Camera, Hash } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { PageContainer } from "@/components/layout/PageContainer";
import { EmptyState } from "@/components/ui/empty-state";
import { apiRequest } from "@/lib/queryClient";
import type { Vehicle, VehicleAlertWithDetails } from "@shared/schema";

const MAKES = [
  "Acura", "Audi", "BMW", "Buick", "Cadillac", "Chevrolet", "Chrysler",
  "Dodge", "Ford", "GMC", "Honda", "Hyundai", "Infiniti", "Jaguar",
  "Jeep", "Kia", "Land Rover", "Lexus", "Lincoln", "Mazda", "Mercedes-Benz",
  "Mitsubishi", "Nissan", "Porsche", "Ram", "Subaru", "Tesla", "Toyota",
  "Volkswagen", "Volvo"
];

const YEARS = Array.from({ length: 27 }, (_, i) => 2026 - i);

interface VehicleWithAlerts extends Vehicle {
  alertCount: number;
}

export default function VehiclesPage() {
  const queryClient = useQueryClient();
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [addMode, setAddMode] = useState<"manual" | "vin">("manual");
  const [formData, setFormData] = useState({
    make: "",
    model: "",
    year: "",
    vin: "",
    nickname: "",
  });

  const { data: vehicles = [], isLoading } = useQuery<VehicleWithAlerts[]>({
    queryKey: ["/api/vehicles"],
  });

  const addVehicleMutation = useMutation({
    mutationFn: (data: typeof formData) => apiRequest("POST", "/api/vehicles/add", {
      ...data,
      year: data.year ? parseInt(data.year, 10) : undefined,
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/vehicles"] });
      setIsAddOpen(false);
      setFormData({ make: "", model: "", year: "", vin: "", nickname: "" });
    },
  });

  const deleteVehicleMutation = useMutation({
    mutationFn: (id: number) => apiRequest("DELETE", `/api/vehicles/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/vehicles"] });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addVehicleMutation.mutate(formData);
  };

  const activeVehicles = vehicles.filter(v => v.isActive);

  return (
    <PageContainer>
      <div className="space-y-6 py-4">
        <div className="flex items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold">My Vehicles</h1>
            <p className="text-sm text-muted-foreground">
              Track your vehicles for NHTSA safety recalls
            </p>
          </div>
          <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
            <DialogTrigger asChild>
              <Button data-testid="button-add-vehicle">
                <Plus className="w-4 h-4 mr-2" />
                Add Vehicle
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Add Vehicle</DialogTitle>
              </DialogHeader>
              <Tabs value={addMode} onValueChange={(v) => setAddMode(v as "manual" | "vin")}>
                <TabsList className="w-full">
                  <TabsTrigger value="manual" className="flex-1" data-testid="tab-manual-entry">
                    <Car className="w-4 h-4 mr-2" />
                    Manual Entry
                  </TabsTrigger>
                  <TabsTrigger value="vin" className="flex-1" data-testid="tab-vin-entry">
                    <Hash className="w-4 h-4 mr-2" />
                    Enter VIN
                  </TabsTrigger>
                </TabsList>
                <TabsContent value="manual">
                  <form onSubmit={handleSubmit} className="space-y-4 mt-4">
                    <div className="space-y-2">
                      <Label>Make</Label>
                      <Select 
                        value={formData.make} 
                        onValueChange={(v) => setFormData(prev => ({ ...prev, make: v }))}
                      >
                        <SelectTrigger data-testid="select-make">
                          <SelectValue placeholder="Select make" />
                        </SelectTrigger>
                        <SelectContent>
                          {MAKES.map(make => (
                            <SelectItem key={make} value={make}>{make}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>Model</Label>
                      <Input 
                        data-testid="input-model"
                        placeholder="e.g., Camry, Accord, F-150"
                        value={formData.model}
                        onChange={(e) => setFormData(prev => ({ ...prev, model: e.target.value }))}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Year</Label>
                      <Select 
                        value={formData.year} 
                        onValueChange={(v) => setFormData(prev => ({ ...prev, year: v }))}
                      >
                        <SelectTrigger data-testid="select-year">
                          <SelectValue placeholder="Select year" />
                        </SelectTrigger>
                        <SelectContent>
                          {YEARS.map(year => (
                            <SelectItem key={year} value={String(year)}>{year}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>Nickname (optional)</Label>
                      <Input 
                        data-testid="input-nickname"
                        placeholder="e.g., My Daily Driver"
                        value={formData.nickname}
                        onChange={(e) => setFormData(prev => ({ ...prev, nickname: e.target.value }))}
                      />
                    </div>
                    <Button 
                      type="submit" 
                      className="w-full" 
                      disabled={addVehicleMutation.isPending || !formData.make || !formData.model || !formData.year}
                      data-testid="button-submit-vehicle"
                    >
                      {addVehicleMutation.isPending ? "Adding..." : "Add Vehicle"}
                    </Button>
                  </form>
                </TabsContent>
                <TabsContent value="vin">
                  <form onSubmit={handleSubmit} className="space-y-4 mt-4">
                    <div className="space-y-2">
                      <Label>VIN (17 characters)</Label>
                      <Input 
                        data-testid="input-vin"
                        placeholder="e.g., 1HGBH41JXMN109186"
                        value={formData.vin}
                        onChange={(e) => setFormData(prev => ({ ...prev, vin: e.target.value.toUpperCase() }))}
                        maxLength={17}
                      />
                      <p className="text-xs text-muted-foreground">
                        Find your VIN on the dashboard near the windshield or inside the driver's door jamb
                      </p>
                    </div>
                    <div className="grid grid-cols-3 gap-2">
                      <div className="space-y-2">
                        <Label>Make</Label>
                        <Input 
                          data-testid="input-vin-make"
                          value={formData.make}
                          onChange={(e) => setFormData(prev => ({ ...prev, make: e.target.value }))}
                          placeholder="Make"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Model</Label>
                        <Input 
                          data-testid="input-vin-model"
                          value={formData.model}
                          onChange={(e) => setFormData(prev => ({ ...prev, model: e.target.value }))}
                          placeholder="Model"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Year</Label>
                        <Input 
                          data-testid="input-vin-year"
                          value={formData.year}
                          onChange={(e) => setFormData(prev => ({ ...prev, year: e.target.value }))}
                          placeholder="Year"
                          type="number"
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label>Nickname (optional)</Label>
                      <Input 
                        data-testid="input-vin-nickname"
                        placeholder="e.g., Family SUV"
                        value={formData.nickname}
                        onChange={(e) => setFormData(prev => ({ ...prev, nickname: e.target.value }))}
                      />
                    </div>
                    <Button 
                      type="submit" 
                      className="w-full" 
                      disabled={addVehicleMutation.isPending || !formData.make || !formData.model || !formData.year}
                      data-testid="button-submit-vin"
                    >
                      {addVehicleMutation.isPending ? "Adding..." : "Add Vehicle"}
                    </Button>
                  </form>
                </TabsContent>
              </Tabs>
            </DialogContent>
          </Dialog>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[1, 2].map(i => (
              <Card key={i} className="animate-pulse">
                <CardContent className="p-4">
                  <div className="h-20 bg-muted rounded" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : activeVehicles.length === 0 ? (
          <EmptyState
            icon={Car}
            title="No Vehicles Added"
            description="Add your vehicles to check for safety recalls from NHTSA."
          />
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {activeVehicles.map((vehicle) => (
              <VehicleCard 
                key={vehicle.id} 
                vehicle={vehicle}
                onDelete={() => deleteVehicleMutation.mutate(vehicle.id)}
              />
            ))}
          </div>
        )}
      </div>
    </PageContainer>
  );
}

function VehicleCard({ 
  vehicle, 
  onDelete 
}: { 
  vehicle: VehicleWithAlerts; 
  onDelete: () => void;
}) {
  const queryClient = useQueryClient();
  const [isExpanded, setIsExpanded] = useState(false);

  const { data: details } = useQuery<{ vehicle: Vehicle; alerts: VehicleAlertWithDetails[] }>({
    queryKey: ["/api/vehicles", vehicle.id],
    enabled: isExpanded,
  });

  const markFixedMutation = useMutation({
    mutationFn: ({ alertId, isFixed }: { alertId: number; isFixed: boolean }) => 
      apiRequest("POST", `/api/vehicles/${alertId}/mark-fixed`, { isFixed }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/vehicles"] });
      queryClient.invalidateQueries({ queryKey: ["/api/vehicles", vehicle.id] });
    },
  });

  const displayName = vehicle.nickname || `${vehicle.year} ${vehicle.make} ${vehicle.model}`;
  const vinDisplay = vehicle.vin ? `...${vehicle.vin.slice(-8)}` : null;

  return (
    <Card className="hover-elevate" data-testid={`card-vehicle-${vehicle.id}`}>
      <CardHeader className="pb-2">
        <div className="flex items-start justify-between gap-2">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center">
              <Car className="w-5 h-5 text-blue-500" />
            </div>
            <div>
              <CardTitle className="text-base">{displayName}</CardTitle>
              {vinDisplay && (
                <p className="text-xs text-muted-foreground">VIN: {vinDisplay}</p>
              )}
            </div>
          </div>
          {vehicle.alertCount > 0 ? (
            <Badge variant="destructive" className="gap-1">
              <AlertTriangle className="w-3 h-3" />
              {vehicle.alertCount} recall{vehicle.alertCount > 1 ? "s" : ""}
            </Badge>
          ) : (
            <Badge variant="outline" className="gap-1 text-green-500 border-green-500/50">
              <CheckCircle className="w-3 h-3" />
              No recalls
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent className="pt-2">
        <div className="flex items-center justify-between">
          <p className="text-sm text-muted-foreground">
            {vehicle.year} {vehicle.make} {vehicle.model}
          </p>
          <div className="flex gap-2">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => setIsExpanded(!isExpanded)}
              data-testid={`button-expand-vehicle-${vehicle.id}`}
            >
              {isExpanded ? "Hide Details" : "View Details"}
            </Button>
            <Button 
              variant="ghost" 
              size="icon"
              onClick={onDelete}
              data-testid={`button-delete-vehicle-${vehicle.id}`}
            >
              <Trash2 className="w-4 h-4 text-destructive" />
            </Button>
          </div>
        </div>

        {isExpanded && details && (
          <div className="mt-4 space-y-3 border-t pt-4">
            {details.alerts.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-2">
                No active recalls for this vehicle
              </p>
            ) : (
              details.alerts.map((alert) => (
                <div 
                  key={alert.id} 
                  className={`p-3 rounded-lg border ${
                    alert.isFixed ? "bg-green-500/5 border-green-500/20" :
                    alert.urgency === "HIGH" ? "bg-red-500/5 border-red-500/20" :
                    alert.urgency === "MEDIUM" ? "bg-orange-500/5 border-orange-500/20" :
                    "bg-yellow-500/5 border-yellow-500/20"
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <Badge 
                          variant={alert.isFixed ? "outline" : "destructive"}
                          className={alert.isFixed ? "text-green-500 border-green-500/50" : ""}
                        >
                          {alert.isFixed ? "Fixed" : alert.urgency}
                        </Badge>
                        <span className="text-xs text-muted-foreground">
                          Campaign #{alert.vehicleRecall.campaignNumber}
                        </span>
                      </div>
                      <p className="text-sm font-medium">{alert.vehicleRecall.component}</p>
                      <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
                        {alert.message || alert.vehicleRecall.summary}
                      </p>
                    </div>
                    <Button
                      variant={alert.isFixed ? "outline" : "default"}
                      size="sm"
                      onClick={() => markFixedMutation.mutate({ 
                        alertId: alert.id, 
                        isFixed: !alert.isFixed 
                      })}
                      data-testid={`button-mark-fixed-${alert.id}`}
                    >
                      {alert.isFixed ? "Undo" : "Mark Fixed"}
                    </Button>
                  </div>
                </div>
              ))
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
