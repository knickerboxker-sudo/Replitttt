import { PageContainer } from "@/components/layout/PageContainer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";

export default function PrivacyPage() {
  const currentYear = new Date().getFullYear();

  return (
    <PageContainer>
      <div className="py-8">
        <Card className="max-w-3xl mx-auto">
          <CardHeader>
            <CardTitle className="text-2xl">Privacy Policy for Sortir</CardTitle>
            <p className="text-sm text-muted-foreground">Last Updated: January 31, {currentYear}</p>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[60vh] pr-4">
              <div className="space-y-6 text-sm">
                <section>
                  <h3 className="font-bold text-base mb-2">1. Information We Collect</h3>
                  <div className="space-y-2">
                    <p className="font-semibold">Information You Provide:</p>
                    <ul className="list-disc pl-5 space-y-1">
                      <li>Vehicle information (make, model, year, VIN - optional)</li>
                      <li>Product information (brand, name, model number, purchase date)</li>
                      <li>Receipt images (grocery receipts, product packaging)</li>
                    </ul>
                    <p className="font-semibold mt-4">Automatically Collected:</p>
                    <ul className="list-disc pl-5 space-y-1">
                      <li>Usage data (pages visited, features used, timestamps)</li>
                      <li>Device information (browser type, operating system)</li>
                      <li>Session data (stored in cookies)</li>
                    </ul>
                  </div>
                </section>

                <section>
                  <h3 className="font-bold text-base mb-2">2. How We Use Your Information</h3>
                  <p>We use your data to:</p>
                  <ul className="list-disc pl-5 mt-2 space-y-1">
                    <li>Match your registered items against recall databases</li>
                    <li>Generate personalized recall alerts</li>
                    <li>Process images using Cohere AI vision models</li>
                    <li>Improve our matching algorithms and service quality</li>
                    <li>Analyze usage patterns to improve the Service</li>
                  </ul>
                </section>

                <section>
                  <h3 className="font-bold text-base mb-2">3. Third-Party Services</h3>
                  <p className="font-semibold">Cohere AI:</p>
                  <p>We use Cohere's APIs to process receipt images and generate alerts. Images and text are sent to Cohere's servers for processing. We do not store images permanently; they are processed and deleted.</p>
                  <p className="font-semibold mt-4">Government APIs:</p>
                  <p>We query FDA, NHTSA, and CPSC public APIs. No personal data is sent to these APIs.</p>
                </section>

                <section>
                  <h3 className="font-bold text-base mb-2">4. Data Storage & Security</h3>
                  <p>Your data is stored in encrypted databases. We use industry-standard security practices. However, no system is 100% secure; you use the Service at your own risk. We do not sell your personal data to third parties.</p>
                </section>

                <section>
                  <h3 className="font-bold text-base mb-2">5. Data Retention</h3>
                  <ul className="list-disc pl-5 mt-2 space-y-1">
                    <li>Active items: Stored indefinitely until you delete them</li>
                    <li>Deleted items: Removed from our database within 30 days</li>
                    <li>Image uploads: Processed immediately and deleted</li>
                    <li>Recall data: Cached for performance</li>
                  </ul>
                </section>

                <section>
                  <h3 className="font-bold text-base mb-2">6. Your Rights</h3>
                  <p>You have the right to access, delete, and correct your data at any time through the application interface.</p>
                </section>

                <section>
                  <h3 className="font-bold text-base mb-2">7. Children's Privacy</h3>
                  <p>Sortir is not intended for children under 13. We do not knowingly collect data from children.</p>
                </section>
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      </div>
    </PageContainer>
  );
}
