import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Plus, Search, Car, Utensils, Package, ChevronRight, Trash2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { PageContainer } from "@/components/layout/PageContainer";
import { EmptyState } from "@/components/ui/empty-state";
import { LoadingSpinner } from "@/components/ui/loading-spinner";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { PantryItem, Vehicle, Product } from "@shared/schema";
import { Link } from "wouter";

type Category = "food" | "vehicle" | "product";

interface BrandGroup {
  brand: string;
  items: Array<{
    id: number;
    category: Category;
    name: string;
    details: string;
  }>;
  alertCount: number;
}

export default function MyBrandsPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [addCategory, setAddCategory] = useState<Category>("food");
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: pantryItems = [], isLoading: loadingPantry } = useQuery<PantryItem[]>({
    queryKey: ["/api/pantry"],
  });

  const { data: vehicles = [], isLoading: loadingVehicles } = useQuery<(Vehicle & { alertCount: number })[]>({
    queryKey: ["/api/vehicles"],
  });

  const { data: products = [], isLoading: loadingProducts } = useQuery<(Product & { alertCount: number })[]>({
    queryKey: ["/api/products"],
  });

  const isLoading = loadingPantry || loadingVehicles || loadingProducts;

  const groupedBrands: BrandGroup[] = (() => {
    const brandMap = new Map<string, BrandGroup>();

    pantryItems.filter(i => i.isActive).forEach(item => {
      const brand = item.brand || "Unknown Brand";
      if (!brandMap.has(brand)) {
        brandMap.set(brand, { brand, items: [], alertCount: 0 });
      }
      brandMap.get(brand)!.items.push({
        id: item.id,
        category: "food",
        name: item.productName,
        details: item.size || "",
      });
    });

    vehicles.filter(v => v.isActive).forEach(vehicle => {
      const brand = vehicle.make;
      if (!brandMap.has(brand)) {
        brandMap.set(brand, { brand, items: [], alertCount: 0 });
      }
      const group = brandMap.get(brand)!;
      group.items.push({
        id: vehicle.id,
        category: "vehicle",
        name: `${vehicle.model} ${vehicle.year}`,
        details: vehicle.nickname || "",
      });
      group.alertCount += vehicle.alertCount || 0;
    });

    products.filter(p => p.isActive).forEach(product => {
      const brand = product.brand || "Unknown Brand";
      if (!brandMap.has(brand)) {
        brandMap.set(brand, { brand, items: [], alertCount: 0 });
      }
      const group = brandMap.get(brand)!;
      group.items.push({
        id: product.id,
        category: "product",
        name: product.productName,
        details: product.category || "",
      });
      group.alertCount += product.alertCount || 0;
    });

    return Array.from(brandMap.values())
      .filter(g => g.brand.toLowerCase().includes(searchQuery.toLowerCase()) ||
        g.items.some(i => i.name.toLowerCase().includes(searchQuery.toLowerCase())))
      .sort((a, b) => b.alertCount - a.alertCount || a.brand.localeCompare(b.brand));
  })();

  const getCategoryIcon = (category: Category) => {
    switch (category) {
      case "food": return <Utensils className="w-3 h-3" />;
      case "vehicle": return <Car className="w-3 h-3" />;
      case "product": return <Package className="w-3 h-3" />;
    }
  };

  const getCategoryColor = (category: Category) => {
    switch (category) {
      case "food": return "bg-green-500/20 text-green-400 border-green-500/30";
      case "vehicle": return "bg-blue-500/20 text-blue-400 border-blue-500/30";
      case "product": return "bg-purple-500/20 text-purple-400 border-purple-500/30";
    }
  };

  return (
    <PageContainer>
      <div className="space-y-6 py-4">
        <div className="flex items-center justify-between gap-4">
          <div>
            <h1 className="text-xl font-bold tracking-tight">My Brands</h1>
            <p className="text-sm text-muted-foreground">
              {groupedBrands.length} brand{groupedBrands.length !== 1 ? "s" : ""} tracked
            </p>
          </div>
          <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
            <DialogTrigger asChild>
              <Button size="sm" data-testid="button-add-item">
                <Plus className="w-4 h-4 mr-2" />
                Add
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add to My Brands</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 pt-4">
                <div className="grid grid-cols-3 gap-2">
                  <Button
                    variant={addCategory === "food" ? "default" : "outline"}
                    onClick={() => setAddCategory("food")}
                    className="flex flex-col items-center gap-1 h-auto py-3"
                    data-testid="button-add-food"
                  >
                    <Utensils className="w-5 h-5" />
                    <span className="text-xs">Food</span>
                  </Button>
                  <Button
                    variant={addCategory === "vehicle" ? "default" : "outline"}
                    onClick={() => setAddCategory("vehicle")}
                    className="flex flex-col items-center gap-1 h-auto py-3"
                    data-testid="button-add-vehicle"
                  >
                    <Car className="w-5 h-5" />
                    <span className="text-xs">Vehicle</span>
                  </Button>
                  <Button
                    variant={addCategory === "product" ? "default" : "outline"}
                    onClick={() => setAddCategory("product")}
                    className="flex flex-col items-center gap-1 h-auto py-3"
                    data-testid="button-add-product"
                  >
                    <Package className="w-5 h-5" />
                    <span className="text-xs">Product</span>
                  </Button>
                </div>
                
                <div className="pt-2">
                  {addCategory === "food" && (
                    <Link href="/?add=food" onClick={() => setShowAddDialog(false)}>
                      <Button className="w-full" data-testid="button-go-add-food">
                        Add Food Item
                        <ChevronRight className="w-4 h-4 ml-2" />
                      </Button>
                    </Link>
                  )}
                  {addCategory === "vehicle" && (
                    <Link href="/vehicles?add=true" onClick={() => setShowAddDialog(false)}>
                      <Button className="w-full" data-testid="button-go-add-vehicle">
                        Add Vehicle
                        <ChevronRight className="w-4 h-4 ml-2" />
                      </Button>
                    </Link>
                  )}
                  {addCategory === "product" && (
                    <Link href="/products?add=true" onClick={() => setShowAddDialog(false)}>
                      <Button className="w-full" data-testid="button-go-add-product">
                        Add Product
                        <ChevronRight className="w-4 h-4 ml-2" />
                      </Button>
                    </Link>
                  )}
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search brands or items..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9"
            data-testid="input-search-brands"
          />
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <LoadingSpinner size="lg" />
          </div>
        ) : groupedBrands.length === 0 ? (
          <EmptyState
            icon={Package}
            title={searchQuery ? "No matches found" : "No brands tracked yet"}
            description={searchQuery 
              ? "Try a different search term."
              : "Add food, vehicles, or products you use to track them for recalls."
            }
            action={!searchQuery && (
              <Button onClick={() => setShowAddDialog(true)} data-testid="button-add-first">
                <Plus className="w-4 h-4 mr-2" />
                Add Your First Brand
              </Button>
            )}
          />
        ) : (
          <div className="space-y-3">
            {groupedBrands.map((group) => (
              <Card key={group.brand} className="hover-elevate" data-testid={`card-brand-${group.brand}`}>
                <CardHeader className="pb-2 flex flex-row items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <CardTitle className="text-base font-semibold">{group.brand}</CardTitle>
                    {group.alertCount > 0 && (
                      <Badge variant="destructive" className="text-xs">
                        {group.alertCount} alert{group.alertCount !== 1 ? "s" : ""}
                      </Badge>
                    )}
                  </div>
                  <span className="text-xs text-muted-foreground">
                    {group.items.length} item{group.items.length !== 1 ? "s" : ""}
                  </span>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="flex flex-wrap gap-2">
                    {group.items.map((item) => (
                      <Badge
                        key={`${item.category}-${item.id}`}
                        variant="outline"
                        className={`${getCategoryColor(item.category)} flex items-center gap-1`}
                        data-testid={`badge-item-${item.category}-${item.id}`}
                      >
                        {getCategoryIcon(item.category)}
                        {item.name}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </PageContainer>
  );
}
