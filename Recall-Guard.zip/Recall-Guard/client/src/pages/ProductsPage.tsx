import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Package, Plus, AlertTriangle, CheckCircle, Trash2, Camera } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { PageContainer } from "@/components/layout/PageContainer";
import { EmptyState } from "@/components/ui/empty-state";
import { apiRequest } from "@/lib/queryClient";
import type { Product, ProductAlertWithDetails } from "@shared/schema";

const CATEGORIES = [
  "Electronics",
  "Toys",
  "Furniture",
  "Appliances",
  "Baby Products",
  "Sports Equipment",
  "Clothing",
  "Health & Beauty",
  "Other"
];


interface ProductWithAlerts extends Product {
  alertCount: number;
}

export default function ProductsPage() {
  const queryClient = useQueryClient();
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [formData, setFormData] = useState({
    brand: "",
    productName: "",
    modelNumber: "",
    category: "Other",
    purchaseDate: "",
    purchaseLocation: "",
  });

  const { data: products = [], isLoading } = useQuery<ProductWithAlerts[]>({
    queryKey: ["/api/products"],
  });

  const addProductMutation = useMutation({
    mutationFn: (data: typeof formData) => apiRequest("POST", "/api/products/add", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      setIsAddOpen(false);
      setFormData({ brand: "", productName: "", modelNumber: "", category: "Other", purchaseDate: "", purchaseLocation: "" });
    },
  });

  const deleteProductMutation = useMutation({
    mutationFn: (id: number) => apiRequest("DELETE", `/api/products/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addProductMutation.mutate(formData);
  };

  const activeProducts = products.filter(p => p.isActive);

  return (
    <PageContainer>
      <div className="space-y-6 py-4">
        <div className="flex items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold">My Products</h1>
            <p className="text-sm text-muted-foreground">
              Track consumer products for CPSC safety recalls
            </p>
          </div>
          <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
            <DialogTrigger asChild>
              <Button data-testid="button-add-product">
                <Plus className="w-4 h-4 mr-2" />
                Add Product
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Add Product</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4 mt-4">
                <div className="space-y-2">
                  <Label>Brand</Label>
                  <Input 
                    data-testid="input-brand"
                    placeholder="e.g., Sony, Fisher-Price, IKEA"
                    value={formData.brand}
                    onChange={(e) => setFormData(prev => ({ ...prev, brand: e.target.value }))}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Product Name *</Label>
                  <Input 
                    data-testid="input-product-name"
                    placeholder="e.g., Wireless Headphones"
                    value={formData.productName}
                    onChange={(e) => setFormData(prev => ({ ...prev, productName: e.target.value }))}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label>Model Number</Label>
                  <Input 
                    data-testid="input-model-number"
                    placeholder="e.g., WH-1000XM4"
                    value={formData.modelNumber}
                    onChange={(e) => setFormData(prev => ({ ...prev, modelNumber: e.target.value }))}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Category</Label>
                  <Select 
                    value={formData.category} 
                    onValueChange={(v) => setFormData(prev => ({ ...prev, category: v }))}
                  >
                    <SelectTrigger data-testid="select-category">
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {CATEGORIES.map(cat => (
                        <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Purchase Date</Label>
                    <Input 
                      data-testid="input-purchase-date"
                      type="date"
                      value={formData.purchaseDate}
                      onChange={(e) => setFormData(prev => ({ ...prev, purchaseDate: e.target.value }))}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Store (optional)</Label>
                    <Input 
                      data-testid="input-purchase-location"
                      placeholder="e.g., Amazon"
                      value={formData.purchaseLocation}
                      onChange={(e) => setFormData(prev => ({ ...prev, purchaseLocation: e.target.value }))}
                    />
                  </div>
                </div>
                <Button 
                  type="submit" 
                  className="w-full" 
                  disabled={addProductMutation.isPending || !formData.productName}
                  data-testid="button-submit-product"
                >
                  {addProductMutation.isPending ? "Adding..." : "Add Product"}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[1, 2].map(i => (
              <Card key={i} className="animate-pulse">
                <CardContent className="p-4">
                  <div className="h-20 bg-muted rounded" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : activeProducts.length === 0 ? (
          <EmptyState
            icon={Package}
            title="No Products Added"
            description="Add consumer products to check for CPSC safety recalls."
          />
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {activeProducts.map((product) => (
              <ProductCard 
                key={product.id} 
                product={product}
                onDelete={() => deleteProductMutation.mutate(product.id)}
              />
            ))}
          </div>
        )}
      </div>
    </PageContainer>
  );
}

function ProductCard({ 
  product, 
  onDelete 
}: { 
  product: ProductWithAlerts; 
  onDelete: () => void;
}) {
  const queryClient = useQueryClient();
  const [isExpanded, setIsExpanded] = useState(false);

  const { data: details } = useQuery<{ product: Product; alerts: ProductAlertWithDetails[] }>({
    queryKey: ["/api/products", product.id],
    enabled: isExpanded,
  });

  const markDiscardedMutation = useMutation({
    mutationFn: ({ alertId, isDiscarded }: { alertId: number; isDiscarded: boolean }) => 
      apiRequest("POST", `/api/products/${alertId}/mark-discarded`, { isDiscarded }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      queryClient.invalidateQueries({ queryKey: ["/api/products", product.id] });
    },
  });

  const displayName = `${product.brand ? product.brand + " " : ""}${product.productName}`;

  return (
    <Card className="hover-elevate" data-testid={`card-product-${product.id}`}>
      <CardHeader className="pb-2">
        <div className="flex items-start justify-between gap-2">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-purple-500/10 flex items-center justify-center">
              <Package className="w-5 h-5 text-purple-500" />
            </div>
            <div>
              <CardTitle className="text-base">{displayName}</CardTitle>
              {product.modelNumber && (
                <p className="text-xs text-muted-foreground">Model: {product.modelNumber}</p>
              )}
            </div>
          </div>
          {product.alertCount > 0 ? (
            <Badge variant="destructive" className="gap-1">
              <AlertTriangle className="w-3 h-3" />
              {product.alertCount} alert{product.alertCount > 1 ? "s" : ""}
            </Badge>
          ) : (
            <Badge variant="outline" className="gap-1 text-green-500 border-green-500/50">
              <CheckCircle className="w-3 h-3" />
              No recalls
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent className="pt-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Badge variant="secondary" className="text-xs">
              {product.category || "Other"}
            </Badge>
            {product.purchaseDate && (
              <span className="text-xs text-muted-foreground">
                Purchased: {new Date(product.purchaseDate).toLocaleDateString()}
              </span>
            )}
          </div>
          <div className="flex gap-2">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => setIsExpanded(!isExpanded)}
              data-testid={`button-expand-product-${product.id}`}
            >
              {isExpanded ? "Hide Details" : "View Details"}
            </Button>
            <Button 
              variant="ghost" 
              size="icon"
              onClick={onDelete}
              data-testid={`button-delete-product-${product.id}`}
            >
              <Trash2 className="w-4 h-4 text-destructive" />
            </Button>
          </div>
        </div>

        {isExpanded && details && (
          <div className="mt-4 space-y-3 border-t pt-4">
            {details.alerts.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-2">
                No active recalls for this product
              </p>
            ) : (
              details.alerts.map((alert) => (
                <div 
                  key={alert.id} 
                  className={`p-3 rounded-lg border ${
                    alert.isDiscarded ? "bg-green-500/5 border-green-500/20" :
                    alert.urgency === "HIGH" ? "bg-red-500/5 border-red-500/20" :
                    alert.urgency === "MEDIUM" ? "bg-orange-500/5 border-orange-500/20" :
                    "bg-yellow-500/5 border-yellow-500/20"
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <Badge 
                          variant={alert.isDiscarded ? "outline" : "destructive"}
                          className={alert.isDiscarded ? "text-green-500 border-green-500/50" : ""}
                        >
                          {alert.isDiscarded ? "Discarded" : alert.urgency}
                        </Badge>
                        <span className="text-xs text-muted-foreground">
                          Recall #{alert.productRecall.recallNumber}
                        </span>
                      </div>
                      <p className="text-sm font-medium">{alert.productRecall.productName}</p>
                      <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
                        {alert.message || alert.productRecall.hazard}
                      </p>
                      {alert.productRecall.cpscUrl && (
                        <a 
                          href={alert.productRecall.cpscUrl} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-xs text-primary hover:underline mt-2 inline-block"
                        >
                          View on CPSC.gov
                        </a>
                      )}
                    </div>
                    <Button
                      variant={alert.isDiscarded ? "outline" : "default"}
                      size="sm"
                      onClick={() => markDiscardedMutation.mutate({ 
                        alertId: alert.id, 
                        isDiscarded: !alert.isDiscarded 
                      })}
                      data-testid={`button-mark-discarded-${alert.id}`}
                    >
                      {alert.isDiscarded ? "Undo" : "Discarded"}
                    </Button>
                  </div>
                </div>
              ))
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
