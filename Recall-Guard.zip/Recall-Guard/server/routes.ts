import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { fetchRecalls, fetchRecallsLast90Days } from "./fda-client";
import { decodeVIN, fetchVehicleRecalls, validateVIN } from "./nhtsa-client";
import { fetchProductRecalls } from "./cpsc-client";
import { vectorStore } from "./vector-store";
import type { InsertPantryItem, InsertVehicle, InsertProduct, InsertVehicleAlert, InsertProductAlert } from "@shared/schema";

let lastRefreshTime = 0;
const REFRESH_DEBOUNCE_MS = 30000;

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  app.get("/api/config", (_req, res) => {
    res.json({ ready: true });
  });

  app.get("/api/terms-status", async (_req, res) => {
    const accepted = await storage.getSetting("termsAccepted");
    res.json({ accepted: accepted === "true" });
  });

  app.post("/api/accept-terms", async (req, res) => {
    const { accepted_terms, accepted_privacy } = req.body;
    if (accepted_terms && accepted_privacy) {
      await storage.setSetting("termsAccepted", "true");
      await storage.setSetting("termsAcceptedAt", new Date().toISOString());
      res.json({ success: true });
    } else {
      res.status(400).json({ error: "Terms and Privacy must be accepted" });
    }
  });

  app.get("/api/stats", async (_req, res) => {
    try {
      const recallCount = await storage.getRecallCount();
      const vehicleRecallCount = await storage.getVehicleRecallCount();
      const productRecallCount = await storage.getProductRecallCount();
      const lastFetch = await storage.getSetting("lastRecallFetch");
      const pantryItems = await storage.getPantryItems();
      const vehicles = await storage.getVehicles();
      const products = await storage.getProducts();
      
      res.json({ 
        recallCount,
        vehicleRecallCount,
        productRecallCount,
        totalRecalls: recallCount + vehicleRecallCount + productRecallCount,
        lastFetch,
        pantryCount: pantryItems.filter(p => p.isActive).length,
        vehicleCount: vehicles.filter(v => v.isActive).length,
        productCount: products.filter(p => p.isActive).length,
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to get stats" });
    }
  });

  // Add food item directly (no scanning)
  app.post("/api/pantry/add", async (req, res) => {
    try {
      const { items } = req.body;
      
      if (!Array.isArray(items) || items.length === 0) {
        return res.status(400).json({ error: "No items provided" });
      }

      const pantryItems: InsertPantryItem[] = items
        .filter((item: { category?: string }) => item.category !== "product")
        .map((item: {
          brand?: string;
          product_name: string;
          size_or_quantity?: string;
          purchase_date?: string;
        }) => ({
          brand: item.brand || null,
          productName: item.product_name,
          size: item.size_or_quantity || null,
          purchaseDate: item.purchase_date || null,
          isActive: true,
        }));

      const productItems: InsertProduct[] = items
        .filter((item: { category?: string }) => item.category === "product")
        .map((item: {
          brand?: string;
          product_name: string;
          size_or_quantity?: string;
          purchase_date?: string;
        }) => ({
          brand: item.brand || null,
          productName: item.product_name,
          modelNumber: null,
          category: "Other",
          purchaseDate: item.purchase_date || null,
          purchaseLocation: null,
          isActive: true,
        }));

      const createdPantry = pantryItems.length > 0 
        ? await storage.createPantryItems(pantryItems) 
        : [];
      
      const createdProducts: any[] = [];
      for (const product of productItems) {
        const created = await storage.createProduct(product);
        createdProducts.push(created);
      }
      
      if (createdPantry.length > 0) {
        await vectorStore.addPantryItems(createdPantry);
        for (const item of createdPantry) {
          vectorStore.matchPantryItem(item).catch(console.error);
        }
      }

      res.json({ 
        pantryItems: createdPantry,
        products: createdProducts,
      });
    } catch (error) {
      console.error("Save error:", error);
      res.status(500).json({ error: "Failed to save items" });
    }
  });

  app.get("/api/pantry", async (_req, res) => {
    try {
      const items = await storage.getPantryItems();
      res.json(items);
    } catch (error) {
      res.status(500).json({ error: "Failed to get pantry items" });
    }
  });

  app.patch("/api/pantry/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      const updated = await storage.updatePantryItem(id, updates);
      if (!updated) {
        return res.status(404).json({ error: "Item not found" });
      }
      if (updates.brand || updates.productName || updates.size) {
        await vectorStore.addPantryItems([updated]);
        vectorStore.matchPantryItem(updated).catch(console.error);
      }
      res.json(updated);
    } catch (error) {
      res.status(500).json({ error: "Failed to update item" });
    }
  });

  app.post("/api/pantry/toggle_active/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updated = await storage.togglePantryItemActive(id);
      
      if (!updated) {
        return res.status(404).json({ error: "Item not found" });
      }

      res.json(updated);
    } catch (error) {
      res.status(500).json({ error: "Failed to toggle item" });
    }
  });

  app.post("/api/pantry/delete/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deletePantryItem(id);
      vectorStore.removePantryItem(id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete item" });
    }
  });

  app.get("/api/vehicles", async (_req, res) => {
    try {
      const vehiclesList = await storage.getVehicles();
      const vehiclesWithAlerts = await Promise.all(
        vehiclesList.map(async (vehicle) => {
          const alerts = await storage.getVehicleAlertsForVehicle(vehicle.id);
          const activeAlerts = alerts.filter(a => !a.isDismissed && !a.isFixed);
          return {
            ...vehicle,
            alertCount: activeAlerts.length,
          };
        })
      );
      res.json(vehiclesWithAlerts);
    } catch (error) {
      res.status(500).json({ error: "Failed to get vehicles" });
    }
  });

  app.get("/api/vehicles/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const vehicle = await storage.getVehicle(id);
      if (!vehicle) {
        return res.status(404).json({ error: "Vehicle not found" });
      }
      const alerts = await storage.getVehicleAlertsForVehicle(id);
      res.json({ vehicle, alerts });
    } catch (error) {
      res.status(500).json({ error: "Failed to get vehicle" });
    }
  });

  app.post("/api/vehicles/add", async (req, res) => {
    try {
      const { make, model, year, vin, nickname } = req.body;
      
      if (!make || !model || !year) {
        return res.status(400).json({ error: "Make, model, and year are required" });
      }

      if (vin) {
        const validation = validateVIN(vin);
        if (!validation.valid) {
          return res.status(400).json({ error: validation.error });
        }
      }

      const vehicleData: InsertVehicle = {
        make,
        model,
        year: parseInt(year),
        vin: vin || null,
        nickname: nickname || null,
        isActive: true,
      };

      const created = await storage.createVehicle(vehicleData);

      const recalls = await fetchVehicleRecalls(make, model, parseInt(year));
      if (recalls.length > 0) {
        await storage.createVehicleRecalls(recalls);
        
        for (const recall of recalls) {
          const storedRecall = await storage.getVehicleRecallByCampaign(recall.campaignNumber);
          if (storedRecall) {
            const exists = await storage.vehicleAlertExists(created.id, storedRecall.id);
            if (!exists) {
              const message = `Recall for ${storedRecall.component || "component"}: ${storedRecall.summary || "See details"}`;
              const alertData: InsertVehicleAlert = {
                vehicleId: created.id,
                vehicleRecallId: storedRecall.id,
                score: 1.0,
                urgency: storedRecall.severity === "high" ? "HIGH" : storedRecall.severity === "medium" ? "MEDIUM" : "LOW",
                message,
                isFixed: false,
                isDismissed: false,
              };
              await storage.createVehicleAlert(alertData);
            }
          }
        }
      }

      const alerts = await storage.getVehicleAlertsForVehicle(created.id);
      res.json({ vehicle: created, alerts, recallCount: recalls.length });
    } catch (error) {
      console.error("Add vehicle error:", error);
      res.status(500).json({ error: "Failed to add vehicle" });
    }
  });

  app.post("/api/vehicles/:id/mark-fixed", async (req, res) => {
    try {
      const alertId = parseInt(req.params.id);
      const { isFixed } = req.body;
      await storage.markVehicleAlertFixed(alertId, isFixed);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to update alert" });
    }
  });

  app.delete("/api/vehicles/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteVehicle(id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete vehicle" });
    }
  });

  app.get("/api/products", async (_req, res) => {
    try {
      const productsList = await storage.getProducts();
      const productsWithAlerts = await Promise.all(
        productsList.map(async (product) => {
          const alerts = await storage.getProductAlertsForProduct(product.id);
          const activeAlerts = alerts.filter(a => !a.isDismissed && !a.isDiscarded);
          return {
            ...product,
            alertCount: activeAlerts.length,
          };
        })
      );
      res.json(productsWithAlerts);
    } catch (error) {
      res.status(500).json({ error: "Failed to get products" });
    }
  });

  app.get("/api/products/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const product = await storage.getProduct(id);
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }
      const alerts = await storage.getProductAlertsForProduct(id);
      res.json({ product, alerts });
    } catch (error) {
      res.status(500).json({ error: "Failed to get product" });
    }
  });

  app.post("/api/products/add", async (req, res) => {
    try {
      const { brand, productName, modelNumber, category, purchaseDate, purchaseLocation } = req.body;
      
      if (!productName) {
        return res.status(400).json({ error: "Product name is required" });
      }

      const productData: InsertProduct = {
        brand: brand || null,
        productName,
        modelNumber: modelNumber || null,
        category: category || "Other",
        purchaseDate: purchaseDate || null,
        purchaseLocation: purchaseLocation || null,
        isActive: true,
      };

      const created = await storage.createProduct(productData);

      await vectorStore.addProducts([created]);
      vectorStore.matchProduct(created).catch(console.error);

      res.json({ product: created });
    } catch (error) {
      console.error("Add product error:", error);
      res.status(500).json({ error: "Failed to add product" });
    }
  });

  app.post("/api/products/:id/mark-discarded", async (req, res) => {
    try {
      const alertId = parseInt(req.params.id);
      const { isDiscarded } = req.body;
      await storage.markProductDiscarded(alertId, isDiscarded);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to update alert" });
    }
  });

  app.delete("/api/products/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteProduct(id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete product" });
    }
  });

  app.get("/api/recalls", async (req, res) => {
    try {
      const { search } = req.query;
      const recallList = await storage.getRecalls();
      
      if (search) {
        const query = (search as string).toLowerCase();
        const filtered = recallList.filter(r => 
          r.productDescription?.toLowerCase().includes(query) || 
          r.company?.toLowerCase().includes(query) ||
          r.reason?.toLowerCase().includes(query)
        );
        return res.json(filtered);
      }
      
      res.json(recallList);
    } catch (error) {
      res.status(500).json({ error: "Failed to get recalls" });
    }
  });

  app.get("/api/vehicle-recalls", async (req, res) => {
    try {
      const { search } = req.query;
      const recallList = await storage.getVehicleRecalls();
      
      if (search) {
        const query = (search as string).toLowerCase();
        const filtered = recallList.filter(r => 
          r.make?.toLowerCase().includes(query) || 
          r.model?.toLowerCase().includes(query) ||
          r.summary?.toLowerCase().includes(query)
        );
        return res.json(filtered);
      }
      
      res.json(recallList);
    } catch (error) {
      res.status(500).json({ error: "Failed to get vehicle recalls" });
    }
  });

  // Real-time NHTSA vehicle recall search by make/model/year
  app.get("/api/vehicle-recalls/search", async (req, res) => {
    try {
      const { make, model, yearStart, yearEnd } = req.query;
      
      if (!make) {
        return res.status(400).json({ error: "Make is required" });
      }
      
      const makeStr = (make as string).toUpperCase();
      const modelStr = model ? (model as string).toUpperCase() : "";
      const startYear = yearStart ? parseInt(yearStart as string) : new Date().getFullYear() - 1;
      const endYear = yearEnd ? parseInt(yearEnd as string) : new Date().getFullYear();
      
      console.log(`Searching NHTSA for ${makeStr} ${modelStr || "(all models)"} years ${startYear}-${endYear}`);
      
      // Build year range
      const yearRange: number[] = [];
      for (let y = startYear; y <= endYear; y++) {
        yearRange.push(y);
      }
      
      let modelsToSearch: string[] = [];
      
      if (modelStr) {
        // Specific model provided
        modelsToSearch = [modelStr];
      } else {
        // No model - fetch all models for this make across the year range
        // Get models for each year and combine them
        const modelSets = await Promise.all(
          yearRange.map(async (year) => {
            try {
              const response = await fetch(
                `https://api.nhtsa.gov/products/vehicle/models?modelYear=${year}&make=${encodeURIComponent(makeStr)}`
              );
              if (!response.ok) return [];
              const data = await response.json();
              return (data.results?.map((r: any) => r.vehicleModel).filter(Boolean) || []) as string[];
            } catch {
              return [];
            }
          })
        );
        
        // Combine and dedupe models
        const allModels = new Set<string>();
        for (const models of modelSets) {
          for (const m of models) {
            // Simplify model names - remove variants like "(SUPER CREW) GAS"
            const baseModel = m.split(" (")[0];
            allModels.add(baseModel);
          }
        }
        modelsToSearch = Array.from(allModels);
        console.log(`Found ${modelsToSearch.length} models for ${makeStr}: ${modelsToSearch.slice(0, 10).join(", ")}...`);
      }
      
      // Fetch recalls for each model/year combination
      const recallPromises: Promise<any[]>[] = [];
      for (const searchModel of modelsToSearch) {
        for (const year of yearRange) {
          recallPromises.push(
            fetchVehicleRecalls(makeStr, searchModel, year).catch(err => {
              // Silently fail for individual model/year combos
              return [];
            })
          );
        }
      }
      
      const recallResults = await Promise.all(recallPromises);
      const allRecalls = recallResults.flat();
      
      // Dedupe by campaign number
      const uniqueRecalls = new Map();
      for (const recall of allRecalls) {
        if (!uniqueRecalls.has(recall.campaignNumber)) {
          uniqueRecalls.set(recall.campaignNumber, recall);
        }
      }
      
      // Also save to database for future reference
      const recallsToSave = Array.from(uniqueRecalls.values());
      if (recallsToSave.length > 0) {
        await storage.createVehicleRecalls(recallsToSave);
      }
      
      console.log(`Found ${recallsToSave.length} unique recalls for ${makeStr} ${modelStr || "(all models)"}`);
      res.json(recallsToSave);
    } catch (error) {
      console.error("Vehicle recall search error:", error);
      res.status(500).json({ error: "Failed to search vehicle recalls" });
    }
  });

  // Get available makes for a year
  app.get("/api/vehicle-makes", async (req, res) => {
    try {
      const { year } = req.query;
      const modelYear = year ? parseInt(year as string) : new Date().getFullYear();
      
      // Fetch all pages of makes (NHTSA paginates at 20 per page)
      let allMakes: string[] = [];
      let offset = 0;
      const maxPerPage = 100;
      
      while (true) {
        const response = await fetch(
          `https://api.nhtsa.gov/products/vehicle/makes?modelYear=${modelYear}&offset=${offset}&max=${maxPerPage}`
        );
        if (!response.ok) break;
        
        const data = await response.json();
        const makes = data.results?.map((r: any) => r.make).filter(Boolean) || [];
        allMakes = allMakes.concat(makes);
        
        // Check if we've fetched all
        const total = data.meta?.pagination?.total || 0;
        if (offset + maxPerPage >= total || makes.length === 0) break;
        offset += maxPerPage;
      }
      
      // Sort and dedupe
      const uniqueMakes = Array.from(new Set(allMakes)).sort();
      res.json(uniqueMakes);
    } catch (error) {
      console.error("Error fetching vehicle makes:", error);
      res.json([]);
    }
  });

  // Get available models for a make and year
  app.get("/api/vehicle-models", async (req, res) => {
    try {
      const { make, year } = req.query;
      if (!make) {
        return res.json([]);
      }
      
      const modelYear = year ? parseInt(year as string) : new Date().getFullYear();
      const makeStr = (make as string).toUpperCase();
      
      const response = await fetch(`https://api.nhtsa.gov/products/vehicle/models?modelYear=${modelYear}&make=${encodeURIComponent(makeStr)}`);
      if (!response.ok) {
        return res.json([]);
      }
      
      const data = await response.json();
      const models = data.results?.map((r: any) => r.vehicleModel).filter(Boolean).sort() || [];
      res.json(models);
    } catch (error) {
      console.error("Error fetching vehicle models:", error);
      res.json([]);
    }
  });

  app.get("/api/product-recalls", async (req, res) => {
    try {
      const { search } = req.query;
      const recallList = await storage.getProductRecalls();
      
      if (search) {
        const query = (search as string).toLowerCase();
        const filtered = recallList.filter(r => 
          r.productName?.toLowerCase().includes(query) || 
          r.description?.toLowerCase().includes(query) ||
          r.hazard?.toLowerCase().includes(query)
        );
        return res.json(filtered);
      }
      
      res.json(recallList);
    } catch (error) {
      res.status(500).json({ error: "Failed to get product recalls" });
    }
  });

  app.post("/api/recalls/refresh", async (_req, res) => {
    try {
      const now = Date.now();
      if (now - lastRefreshTime < REFRESH_DEBOUNCE_MS) {
        return res.status(429).json({ 
          error: "Please wait before refreshing again",
          retryAfter: Math.ceil((REFRESH_DEBOUNCE_MS - (now - lastRefreshTime)) / 1000)
        });
      }
      lastRefreshTime = now;

      // Fetch from all sources
      const [fdaRecalls, cpscRecalls] = await Promise.all([
        fetchRecalls(365),
        fetchProductRecalls(90),
      ]);
      
      const fdaCreated = await storage.createRecalls(fdaRecalls);
      const cpscCreated = await storage.createProductRecalls(cpscRecalls);

      // Also try to fetch some default common vehicle recalls to populate the DB
      // since vehicle recalls are currently only fetched when a vehicle is added.
      // This helps the search page have data.
      const commonMakes = ["FORD", "DODGE", "TOYOTA", "HONDA", "CHEVROLET", "RAM"];
      const currentYear = new Date().getFullYear();
      
      const vehicleRecallPromises = commonMakes.map(make => 
        fetchVehicleRecalls(make, "", currentYear).catch(err => {
          console.error(`Failed to fetch common vehicle recalls for ${make}:`, err);
          return [];
        })
      );
      const vehicleRecallsResults = await Promise.all(vehicleRecallPromises);
      const flattenedVehicleRecalls = vehicleRecallsResults.flat();
      
      if (flattenedVehicleRecalls.length > 0) {
        await storage.createVehicleRecalls(flattenedVehicleRecalls);
      }
      
      await storage.setSetting("lastRecallFetch", new Date().toISOString());
      
      const allRecalls = await storage.getRecalls();
      await vectorStore.addRecalls(allRecalls);
      
      const allProductRecalls = await storage.getProductRecalls();
      await vectorStore.addProductRecalls(allProductRecalls);
      
      vectorStore.matchAllPantryItems().catch(console.error);
      vectorStore.matchAllProducts().catch(console.error);

      res.json({ 
        fdaCount: allRecalls.length,
        cpscCount: allProductRecalls.length,
        vehicleCount: flattenedVehicleRecalls.length,
        newFdaRecalls: fdaCreated,
        newCpscRecalls: cpscCreated,
      });
    } catch (error) {
      console.error("Refresh recalls error:", error);
      res.status(500).json({ error: "Failed to refresh recalls" });
    }
  });

  app.get("/api/alerts", async (_req, res) => {
    try {
      const alerts = await storage.getAlertsWithDetails();
      res.json(alerts);
    } catch (error) {
      res.status(500).json({ error: "Failed to get alerts" });
    }
  });

  app.get("/api/unified-alerts", async (_req, res) => {
    try {
      const alerts = await storage.getUnifiedAlerts();
      res.json(alerts);
    } catch (error) {
      res.status(500).json({ error: "Failed to get unified alerts" });
    }
  });

  app.post("/api/alerts/dismiss/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { category } = req.body;
      
      if (category === "vehicle") {
        await storage.dismissVehicleAlert(id);
      } else if (category === "product") {
        await storage.dismissProductAlert(id);
      } else {
        await storage.dismissAlert(id);
      }
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to dismiss alert" });
    }
  });

  return httpServer;
}
